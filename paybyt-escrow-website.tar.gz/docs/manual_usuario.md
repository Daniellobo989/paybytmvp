# Manual do Usuário - Sistema de Escrow Multisig com Bitcoin

## Introdução

Bem-vindo ao sistema de escrow multisig com Bitcoin do PayByt! Este manual irá guiá-lo através das funcionalidades do sistema e como utilizá-las para realizar transações seguras.

## O que é um Escrow Multisig?

Um escrow multisig (multi-assinatura) é um sistema que utiliza endereços Bitcoin especiais que requerem múltiplas assinaturas para movimentar fundos. No nosso caso, utilizamos um esquema 2-de-3, onde três partes estão envolvidas:

1. **Comprador**: Quem envia o pagamento
2. **Vendedor**: Quem recebe o pagamento após entregar o produto/serviço
3. **Mediador** (PayByt): Um terceiro imparcial que intervém apenas em caso de disputas

Para liberar os fundos, são necessárias 2 das 3 assinaturas, o que garante segurança e flexibilidade.

## Como Funciona

### Fluxo Básico

1. O comprador cria um escrow e envia Bitcoin para o endereço multisig
2. O vendedor envia o produto ou presta o serviço
3. O comprador confirma o recebimento
4. Os fundos são liberados para o vendedor

### Em Caso de Disputas

Se houver problemas com a transação:

1. Qualquer parte pode abrir uma disputa
2. O mediador (PayByt) analisa o caso
3. O mediador decide para onde os fundos devem ir
4. Os fundos são liberados conforme a decisão

## Guia Passo a Passo

### Criar um Novo Escrow

1. Acesse a página "Escrow" e selecione a aba "Criar Escrow"
2. Preencha os campos:
   - **Endereço Bitcoin do Comprador**: Seu endereço Bitcoin ou deixe em branco para gerar um novo
   - **Endereço Bitcoin do Vendedor**: Endereço Bitcoin do vendedor
   - **Valor em Bitcoin**: Quantidade de BTC a ser enviada
   - **Descrição da Transação**: Detalhes sobre o produto ou serviço
   - **Período de Timelock**: Tempo após o qual os fundos podem ser devolvidos automaticamente
3. Clique em "Criar Escrow Multisig"
4. Se um novo par de chaves for gerado, faça o download da chave privada e guarde-a em local seguro
5. Envie a quantidade exata de Bitcoin para o endereço multisig gerado
6. Clique em "Verificar Financiamento" para confirmar que os fundos foram recebidos

### Visualizar e Gerenciar um Escrow

1. Acesse a página "Escrow" e selecione a aba "Visualizar Escrow"
2. Digite o ID do escrow (formato ESC12345) e clique em "Buscar Escrow"
3. Você verá os detalhes completos do escrow, incluindo status, endereços e valores

### Confirmar Recebimento do Produto/Serviço

1. Na página de visualização do escrow, clique em "Confirmar Recebimento do Produto/Serviço"
2. Isso mudará o status do escrow para "Em Andamento"

### Liberar Fundos para o Vendedor

1. Na página de visualização do escrow, insira sua chave privada no campo apropriado
2. Clique em "Liberar Fundos para Vendedor"
3. Os fundos serão transferidos para o endereço do vendedor
4. O status do escrow será atualizado para "Concluído"

### Reembolsar o Comprador

1. Na página de visualização do escrow, insira sua chave privada no campo apropriado
2. Clique em "Reembolsar Comprador"
3. Os fundos serão devolvidos ao endereço do comprador
4. O status do escrow será atualizado para "Reembolsado"

### Abrir uma Disputa

1. Na página de visualização do escrow, clique em "Abrir Disputa"
2. Descreva o motivo da disputa no campo que aparece
3. Clique em "Confirmar"
4. O status do escrow será atualizado para "Em Disputa"
5. Um mediador da PayByt analisará o caso e tomará uma decisão

### Visualizar Histórico de Escrows

1. Acesse a página "Escrow" e selecione a aba "Histórico"
2. Você verá uma lista de todos os seus escrows
3. Use os filtros para visualizar escrows específicos (Todos, Ativos, Concluídos)
4. Clique em "Ver Detalhes" para acessar informações completas de um escrow específico

## Dicas de Segurança

1. **Guarde suas chaves privadas em local seguro**: Elas são necessárias para movimentar os fundos
2. **Verifique sempre os endereços Bitcoin**: Confirme que os endereços estão corretos antes de enviar fundos
3. **Mantenha o ID do escrow**: Você precisará dele para acessar e gerenciar seu escrow
4. **Descreva claramente a transação**: Uma descrição detalhada ajuda em caso de disputas
5. **Confirme o recebimento apenas após verificar o produto/serviço**: Uma vez confirmado, você está indicando que está satisfeito

## Perguntas Frequentes

### O que acontece se eu perder minha chave privada?
Se você perder sua chave privada, ainda será possível movimentar os fundos com a combinação das outras duas chaves (vendedor + mediador ou comprador + mediador).

### Quanto tempo leva para os fundos serem liberados?
A liberação dos fundos é quase instantânea após a confirmação e assinatura da transação. No entanto, a transação ainda precisa ser confirmada na rede Bitcoin, o que pode levar de 10 minutos a algumas horas.

### Há taxas para usar o sistema de escrow?
Atualmente, o sistema está em fase de testes e não há taxas além das taxas normais da rede Bitcoin para processar as transações.

### Como funciona o período de timelock?
O timelock define um período após o qual os fundos podem ser devolvidos ao comprador se não houver acordo. Isso protege o comprador em caso de não entrega do produto/serviço.

### O sistema é seguro?
Sim, o sistema utiliza tecnologia multisig da rede Bitcoin, que é altamente segura. Além disso, as chaves privadas são armazenadas apenas no navegador do cliente, nunca em nossos servidores.

## Suporte

Se você tiver dúvidas ou precisar de ajuda, entre em contato com nossa equipe de suporte:

- Email: suporte@paybyt.com
- Chat: Disponível no canto inferior direito da página
- Horário de atendimento: Segunda a sexta, das 9h às 18h
