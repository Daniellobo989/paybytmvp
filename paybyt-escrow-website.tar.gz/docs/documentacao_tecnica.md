# Documentação Técnica - Sistema de Escrow Multisig com Bitcoin

## Visão Geral

O sistema de escrow multisig com Bitcoin do PayByt é uma solução que permite transações seguras entre compradores e vendedores, utilizando endereços multisig 2-de-3 na rede Bitcoin. Este documento descreve a implementação técnica do sistema, incluindo a arquitetura, os componentes principais e os fluxos de operação.

## Arquitetura

O sistema foi implementado utilizando uma arquitetura de frontend modular com React e TypeScript, com os seguintes componentes principais:

### Serviços

1. **bitcoinService.ts**: Responsável pela integração com a rede Bitcoin
2. **escrowService.ts**: Gerencia o ciclo de vida dos escrows
3. **bitcoinPaymentService.ts**: Integra com BTCPay Server para processamento de pagamentos

### Componentes de Frontend

1. **EscrowCreator**: Interface para criação de novos escrows
2. **EscrowViewer**: Interface para visualização e gerenciamento de escrows existentes
3. **EscrowHistory**: Interface para listagem do histórico de escrows

### Páginas

1. **HomePage**: Página inicial com informações sobre o sistema
2. **EscrowPage**: Página principal que integra os componentes de escrow

## Detalhes de Implementação

### bitcoinService.ts

Este serviço implementa as funcionalidades de baixo nível para interação com a rede Bitcoin:

- Criação de endereços multisig P2SH (2-de-3)
- Geração de pares de chaves Bitcoin
- Verificação de saldos e transações
- Criação e transmissão de transações

```typescript
// Exemplo de criação de endereço multisig
createMultisigAddress(
  buyerPubKey: string,
  sellerPubKey: string,
  mediatorPubKey: string
): MultisigAddress {
  // Implementação usando bitcoinjs-lib
  const pubkeys = [
    Buffer.from(buyerPubKey, 'hex'),
    Buffer.from(sellerPubKey, 'hex'),
    Buffer.from(mediatorPubKey, 'hex')
  ].map(p => bitcoin.ECPair.fromPublicKey(p).publicKey);
  
  const p2sh = bitcoin.payments.p2sh({
    redeem: bitcoin.payments.p2ms({ m: 2, pubkeys, network: bitcoin.networks.testnet })
  });
  
  return {
    address: p2sh.address!,
    redeemScript: p2sh.redeem!.output.toString('hex')
  };
}
```

### escrowService.ts

Este serviço gerencia o ciclo de vida completo dos escrows:

- Criação de escrows
- Verificação de financiamento
- Confirmação de entrega
- Liberação de fundos
- Reembolso
- Abertura e resolução de disputas

```typescript
// Exemplo de criação de escrow
async createEscrow(
  buyerAddress: string,
  sellerAddress: string,
  amount: string,
  description: string,
  timelock: string
): Promise<EscrowData> {
  // Gerar ID único para o escrow
  const escrowId = 'ESC' + uuidv4().substring(0, 8).toUpperCase();
  
  // Criar endereço multisig 2-de-3
  const multisigAddress = bitcoinService.createMultisigAddress(
    buyerAddress,
    sellerAddress,
    this.mediatorPubKey
  );
  
  // Criar objeto de escrow
  const escrow: EscrowData = {
    escrowId,
    escrowAddress: multisigAddress.address,
    redeemScript: multisigAddress.redeemScript,
    buyerAddress,
    sellerAddress,
    mediatorAddress: this.mediatorPubKey,
    amount,
    description,
    timelock,
    status: 'created',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    deliveryConfirmed: false
  };
  
  // Armazenar escrow
  this.escrows.set(escrowId, escrow);
  this.saveToStorage();
  
  return escrow;
}
```

### bitcoinPaymentService.ts

Este serviço integra com BTCPay Server para processamento de pagamentos:

- Criação de faturas de pagamento
- Verificação de status de pagamentos
- Suporte para Lightning Network

```typescript
// Exemplo de criação de fatura de pagamento
async createInvoice(amount: string, description: string, orderId?: string): Promise<PaymentInvoice> {
  // Gerar ID único para a fatura
  const invoiceId = 'INV' + Math.random().toString(36).substring(2, 10).toUpperCase();
  
  // Calcular data de expiração (30 minutos a partir de agora)
  const createdAt = new Date();
  const expiresAt = new Date(createdAt.getTime() + 30 * 60 * 1000);
  
  // Gerar URL de pagamento
  const paymentUrl = `${this.config.serverUrl}/i/${invoiceId}`;
  
  // Gerar QR code para o pagamento
  const qrCodeUrl = await this.generateQRCode(`bitcoin:?amount=${amount}&label=${encodeURIComponent(description)}`);
  
  // Criar objeto de fatura
  const invoice: PaymentInvoice = {
    invoiceId,
    amount,
    paymentUrl,
    qrCodeUrl,
    status: 'new',
    createdAt: createdAt.toISOString(),
    expiresAt: expiresAt.toISOString()
  };
  
  return invoice;
}
```

## Fluxos de Operação

### Criação de Escrow

1. O comprador acessa a página de criação de escrow
2. Fornece o endereço Bitcoin do vendedor, valor e descrição
3. O sistema gera um endereço multisig 2-de-3
4. O comprador envia Bitcoin para o endereço multisig

### Confirmação de Entrega

1. O comprador recebe o produto/serviço
2. Acessa a página de visualização do escrow
3. Confirma a entrega, mudando o status para "em andamento"

### Liberação de Fundos

1. O comprador fornece sua chave privada
2. O sistema cria uma transação para liberar os fundos para o vendedor
3. A transação é transmitida para a rede Bitcoin
4. O status do escrow é atualizado para "concluído"

### Resolução de Disputas

1. Comprador ou vendedor abre uma disputa
2. O mediador analisa o caso
3. O mediador decide para onde os fundos devem ir
4. O sistema cria uma transação para liberar os fundos conforme decisão
5. A transação é transmitida para a rede Bitcoin

## Considerações de Segurança

1. **Armazenamento de Chaves**: As chaves privadas são armazenadas apenas no navegador do cliente, nunca no servidor
2. **Multisig 2-de-3**: Requer duas assinaturas para movimentar fundos, aumentando a segurança
3. **Timelock**: Implementação de timelock para permitir reembolso após um período específico
4. **Verificação de Transações**: Verificação de confirmações na rede Bitcoin antes de considerar transações como concluídas

## Limitações e Melhorias Futuras

1. **Integração com Rede Principal**: Atualmente implementado para a rede de teste, futuramente será migrado para a rede principal
2. **Melhorias na Interface**: Adicionar mais feedback visual e notificações em tempo real
3. **Suporte a Múltiplas Carteiras**: Integrar com carteiras populares como Ledger, Trezor, etc.
4. **Escalabilidade**: Implementar soluções de segunda camada para reduzir taxas e aumentar velocidade
5. **Auditoria de Segurança**: Realizar auditoria de segurança completa antes do lançamento em produção

## Tecnologias Utilizadas

- **Frontend**: React, TypeScript, Tailwind CSS
- **Bitcoin**: bitcoinjs-lib
- **Pagamentos**: BTCPay Server
- **Ferramentas**: Vite, QR Code

## Conclusão

O sistema de escrow multisig com Bitcoin do PayByt oferece uma solução segura e descentralizada para transações entre compradores e vendedores. A implementação atual demonstra a viabilidade do conceito e estabelece uma base sólida para desenvolvimento futuro.
