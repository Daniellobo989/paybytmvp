# Guia de Instalação - Sistema de Escrow Multisig com Bitcoin

Este guia fornece instruções passo a passo para instalar e configurar o sistema de escrow multisig com Bitcoin do PayByt.

## Pré-requisitos

Antes de começar, certifique-se de ter instalado:

- Node.js (versão 18 ou superior)
- npm (normalmente instalado com o Node.js)
- Git

## Instalação

### 1. Clone o Repositório

```bash
git clone https://github.com/Daniellobo989/paybytmvp.git
cd paybytmvp
```

### 2. Instale as Dependências

```bash
npm install
```

### 3. Configure as Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto com o seguinte conteúdo:

```
VITE_BTCPAY_SERVER_URL=https://testnet.demo.btcpayserver.org
VITE_BTCPAY_STORE_ID=AYkzTyGM1vE4LQxWvVJcgS
VITE_BITCOIN_NETWORK=testnet
```

### 4. Inicie o Servidor de Desenvolvimento

```bash
npm run dev
```

O servidor estará disponível em `http://localhost:3000`.

## Configuração para Produção

### 1. Construa a Versão de Produção

```bash
npm run build
```

Isso criará uma pasta `dist` com os arquivos otimizados para produção.

### 2. Teste a Versão de Produção Localmente

```bash
npm run preview
```

### 3. Implante em um Servidor Web

Você pode implantar os arquivos da pasta `dist` em qualquer servidor web estático, como:

- GitHub Pages
- Netlify
- Vercel
- Amazon S3
- Servidor Apache/Nginx

## Integração com BTCPay Server

Para utilizar o sistema com um BTCPay Server real:

1. Configure seu próprio servidor BTCPay ou use um serviço hospedado
2. Crie uma loja no BTCPay Server
3. Gere uma chave de API com permissões para criar faturas
4. Atualize as variáveis de ambiente com suas próprias credenciais

## Configuração da Rede Bitcoin

Por padrão, o sistema está configurado para usar a rede de teste do Bitcoin (testnet). Para usar a rede principal:

1. Altere a variável de ambiente `VITE_BITCOIN_NETWORK` para `mainnet`
2. Atualize a configuração do BTCPay Server para usar a rede principal
3. Certifique-se de testar exaustivamente antes de usar com Bitcoin real

## Solução de Problemas

### Problemas com Dependências

Se encontrar problemas com as dependências, tente:

```bash
npm clean-install
```

### Erros de Compilação

Se encontrar erros durante a compilação:

1. Verifique se todas as dependências estão instaladas
2. Verifique se as versões do Node.js e npm são compatíveis
3. Limpe o cache do npm: `npm cache clean --force`

### Problemas de Conexão com BTCPay Server

Se não conseguir conectar ao BTCPay Server:

1. Verifique se as credenciais estão corretas
2. Confirme se o servidor está acessível a partir do seu ambiente
3. Verifique os logs do console para mensagens de erro específicas

## Recursos Adicionais

- [Documentação Técnica](./documentacao_tecnica.md)
- [Manual do Usuário](./manual_usuario.md)
- [Documentação do BTCPay Server](https://docs.btcpayserver.org/)
- [Documentação do bitcoinjs-lib](https://github.com/bitcoinjs/bitcoinjs-lib)
