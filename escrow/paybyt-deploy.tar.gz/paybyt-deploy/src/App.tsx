import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import HomePage from './components/pages/HomePage';
import ProductPage from './components/pages/ProductPage';
import LoginPage from './components/pages/LoginPage';
import RegisterPage from './components/pages/RegisterPage';
import CheckoutPage from './components/pages/CheckoutPage';
import TransactionsPage from './components/pages/TransactionsPage';
import TransactionDetailPage from './components/pages/TransactionDetailPage';
import MessagesPage from './components/pages/MessagesPage';
import ConversationPage from './components/pages/ConversationPage';

function App() {
  return (
    <Router basename="/paybytmvp">
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/product/:id" element={<ProductPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/checkout/:id" element={<CheckoutPage />} />
            <Route path="/transactions" element={<TransactionsPage />} />
            <Route path="/transaction/:id" element={<TransactionDetailPage />} />
            <Route path="/messages" element={<MessagesPage />} />
            <Route path="/conversation/:id" element={<ConversationPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
