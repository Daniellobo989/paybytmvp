const express = require('express');
const AuthenticationAPI = require('../api/authenticationAPI');

// Inicializar o roteador
const router = express.Router();

// Inicializar a API de autenticação
const authAPI = new AuthenticationAPI();

// Inicializar componentes necessários
(async () => {
  await authAPI.initialize();
  console.log('API de Autenticação inicializada com sucesso');
})();

/**
 * @route   POST /api/auth/identity
 * @desc    Gera uma nova identidade anônima
 * @access  Public
 */
router.post('/identity', async (req, res) => {
  try {
    const identity = await authAPI.generateIdentity();
    res.json(identity);
  } catch (error) {
    console.error('Erro ao gerar identidade:', error);
    res.status(500).json({ error: 'Erro ao gerar identidade' });
  }
});

/**
 * @route   POST /api/auth/challenge
 * @desc    Gera um desafio para autenticação
 * @access  Public
 */
router.post('/challenge', async (req, res) => {
  try {
    const { identityId } = req.body;
    
    if (!identityId) {
      return res.status(400).json({ error: 'ID de identidade é obrigatório' });
    }
    
    const challenge = await authAPI.generateChallenge(identityId);
    res.json(challenge);
  } catch (error) {
    console.error('Erro ao gerar desafio:', error);
    res.status(500).json({ error: 'Erro ao gerar desafio' });
  }
});

/**
 * @route   POST /api/auth/verify
 * @desc    Verifica uma resposta ao desafio e autentica o usuário
 * @access  Public
 */
router.post('/verify', async (req, res) => {
  try {
    const { identityId, challenge, signature, publicKey } = req.body;
    
    if (!identityId || !challenge || !signature || !publicKey) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }
    
    const result = await authAPI.verifyChallenge(identityId, challenge, signature, publicKey);
    res.json(result);
  } catch (error) {
    console.error('Erro ao verificar desafio:', error);
    res.status(401).json({ error: 'Autenticação falhou' });
  }
});

/**
 * @route   POST /api/auth/blind-signature
 * @desc    Gera uma assinatura cega para autenticação anônima
 * @access  Public
 */
router.post('/blind-signature', async (req, res) => {
  try {
    const { message, blindingFactor } = req.body;
    
    if (!message || !blindingFactor) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }
    
    const result = await authAPI.generateBlindSignature(message, blindingFactor);
    res.json(result);
  } catch (error) {
    console.error('Erro ao gerar assinatura cega:', error);
    res.status(500).json({ error: 'Erro ao gerar assinatura cega' });
  }
});

/**
 * @route   POST /api/auth/verify-blind-signature
 * @desc    Verifica uma assinatura cega e autentica o usuário
 * @access  Public
 */
router.post('/verify-blind-signature', async (req, res) => {
  try {
    const { signatureId, message, unblindedSignature } = req.body;
    
    if (!signatureId || !message || !unblindedSignature) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }
    
    const result = await authAPI.verifyBlindSignature(signatureId, message, unblindedSignature);
    res.json(result);
  } catch (error) {
    console.error('Erro ao verificar assinatura cega:', error);
    res.status(401).json({ error: 'Autenticação falhou' });
  }
});

/**
 * @route   GET /api/auth/verify-token
 * @desc    Verifica um token de acesso anônimo
 * @access  Private
 */
router.get('/verify-token', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ error: 'Token não fornecido' });
    }
    
    const decoded = authAPI.verifyToken(token);
    res.json({ valid: true, identity: decoded });
  } catch (error) {
    console.error('Erro ao verificar token:', error);
    res.status(401).json({ valid: false, error: 'Token inválido' });
  }
});

module.exports = router;
