const express = require('express');
const AuthEscrowIntegrationService = require('../services/authEscrowIntegrationService');

// Inicializar o roteador
const router = express.Router();

// Inicializar o serviço de integração
const integrationService = new AuthEscrowIntegrationService();

// Inicializar componentes necessários
(async () => {
  await integrationService.initialize();
  console.log('Serviço de integração Auth-Escrow inicializado com sucesso');
})();

/**
 * @route   POST /api/integration/escrow
 * @desc    Cria um novo escrow usando uma identidade anônima
 * @access  Private
 */
router.post('/escrow', async (req, res) => {
  try {
    const { escrowData, identityId, privateKey } = req.body;
    
    if (!escrowData || !identityId || !privateKey) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }
    
    const escrow = await integrationService.createEscrowWithAnonymousIdentity(
      escrowData,
      identityId,
      privateKey
    );
    
    res.json(escrow);
  } catch (error) {
    console.error('Erro ao criar escrow com identidade anônima:', error);
    res.status(500).json({ error: 'Erro ao criar escrow' });
  }
});

/**
 * @route   GET /api/integration/escrow/:identityId
 * @desc    Obtém os escrows associados a uma identidade anônima
 * @access  Private
 */
router.get('/escrow/:identityId', async (req, res) => {
  try {
    const { identityId } = req.params;
    
    if (!identityId) {
      return res.status(400).json({ error: 'ID de identidade é obrigatório' });
    }
    
    const escrows = await integrationService.getEscrowsByAnonymousIdentity(identityId);
    
    res.json(escrows);
  } catch (error) {
    console.error('Erro ao obter escrows por identidade anônima:', error);
    res.status(500).json({ error: 'Erro ao obter escrows' });
  }
});

/**
 * @route   POST /api/integration/escrow/:escrowId/confirm
 * @desc    Confirma a entrega de um escrow usando uma identidade anônima
 * @access  Private
 */
router.post('/escrow/:escrowId/confirm', async (req, res) => {
  try {
    const { escrowId } = req.params;
    const { identityId, privateKey } = req.body;
    
    if (!escrowId || !identityId || !privateKey) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }
    
    const result = await integrationService.confirmEscrowDeliveryWithAnonymousIdentity(
      escrowId,
      identityId,
      privateKey
    );
    
    res.json(result);
  } catch (error) {
    console.error('Erro ao confirmar entrega com identidade anônima:', error);
    res.status(500).json({ error: 'Erro ao confirmar entrega' });
  }
});

/**
 * @route   POST /api/integration/escrow/:escrowId/release
 * @desc    Libera os fundos de um escrow usando uma identidade anônima
 * @access  Private
 */
router.post('/escrow/:escrowId/release', async (req, res) => {
  try {
    const { escrowId } = req.params;
    const { identityId, privateKey } = req.body;
    
    if (!escrowId || !identityId || !privateKey) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }
    
    const result = await integrationService.releaseEscrowFundsWithAnonymousIdentity(
      escrowId,
      identityId,
      privateKey
    );
    
    res.json(result);
  } catch (error) {
    console.error('Erro ao liberar fundos com identidade anônima:', error);
    res.status(500).json({ error: 'Erro ao liberar fundos' });
  }
});

/**
 * @route   POST /api/integration/escrow/:escrowId/dispute
 * @desc    Abre uma disputa em um escrow usando uma identidade anônima
 * @access  Private
 */
router.post('/escrow/:escrowId/dispute', async (req, res) => {
  try {
    const { escrowId } = req.params;
    const { identityId, privateKey, reason } = req.body;
    
    if (!escrowId || !identityId || !privateKey || !reason) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }
    
    const result = await integrationService.openEscrowDisputeWithAnonymousIdentity(
      escrowId,
      identityId,
      privateKey,
      reason
    );
    
    res.json(result);
  } catch (error) {
    console.error('Erro ao abrir disputa com identidade anônima:', error);
    res.status(500).json({ error: 'Erro ao abrir disputa' });
  }
});

module.exports = router;
