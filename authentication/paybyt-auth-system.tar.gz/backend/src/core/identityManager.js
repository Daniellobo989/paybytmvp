const sodium = require('libsodium-wrappers');
const crypto = require('crypto');

/**
 * Gerenciador de Identidades para o Sistema de Autenticação Anônima
 * 
 * Este módulo implementa a criação e gerenciamento de identidades anônimas
 * utilizando criptografia de chave pública EdDSA (Ed25519) e técnicas de
 * stealth addresses para garantir privacidade nas transações.
 */
class IdentityManager {
  /**
   * Inicializa o gerenciador de identidades
   */
  constructor() {
    this.initialized = false;
  }

  /**
   * Inicializa a biblioteca de criptografia
   */
  async initialize() {
    await sodium.ready;
    this.initialized = true;
  }

  /**
   * Gera um novo par de chaves para identidade anônima
   * @returns {Object} Par de chaves contendo chave pública e privada
   */
  async generateKeyPair() {
    if (!this.initialized) await this.initialize();
    
    const keyPair = sodium.crypto_sign_keypair();
    
    return {
      publicKey: Buffer.from(keyPair.publicKey).toString('hex'),
      privateKey: Buffer.from(keyPair.privateKey).toString('hex'),
      identityId: this._generateIdentityId(keyPair.publicKey)
    };
  }

  /**
   * Gera um identificador único para a identidade baseado na chave pública
   * @param {Buffer} publicKey - Chave pública da identidade
   * @returns {String} Identificador único da identidade
   * @private
   */
  _generateIdentityId(publicKey) {
    const hash = crypto.createHash('sha256').update(publicKey).digest('hex');
    return `id_${hash.substring(0, 16)}`;
  }

  /**
   * Gera um stealth address para uma transação
   * @param {String} recipientPublicKey - Chave pública do destinatário em formato hex
   * @returns {Object} Stealth address e informações relacionadas
   */
  async generateStealthAddress(recipientPublicKey) {
    if (!this.initialized) await this.initialize();
    
    // Gerar um par de chaves efêmero
    const ephemeralKeyPair = sodium.crypto_box_keypair();
    
    // Converter a chave pública do destinatário de hex para Uint8Array
    const recipientPubKey = Buffer.from(recipientPublicKey, 'hex');
    
    // Calcular o segredo compartilhado
    const sharedSecret = sodium.crypto_scalarmult(
      ephemeralKeyPair.privateKey,
      recipientPubKey
    );
    
    // Derivar o stealth address usando o segredo compartilhado
    const stealthAddressBytes = sodium.crypto_generichash(32, sharedSecret);
    const stealthAddress = Buffer.from(stealthAddressBytes).toString('hex');
    
    return {
      stealthAddress,
      ephemeralPublicKey: Buffer.from(ephemeralKeyPair.publicKey).toString('hex')
    };
  }

  /**
   * Recupera o stealth address a partir da chave privada do destinatário e da chave pública efêmera
   * @param {String} privateKey - Chave privada do destinatário em formato hex
   * @param {String} ephemeralPublicKey - Chave pública efêmera em formato hex
   * @returns {String} Stealth address recuperado
   */
  async recoverStealthAddress(privateKey, ephemeralPublicKey) {
    if (!this.initialized) await this.initialize();
    
    // Converter as chaves de hex para Uint8Array
    const privKey = Buffer.from(privateKey, 'hex');
    const ephemPubKey = Buffer.from(ephemeralPublicKey, 'hex');
    
    // Calcular o segredo compartilhado
    const sharedSecret = sodium.crypto_scalarmult(
      privKey,
      ephemPubKey
    );
    
    // Derivar o stealth address usando o segredo compartilhado
    const stealthAddressBytes = sodium.crypto_generichash(32, sharedSecret);
    return Buffer.from(stealthAddressBytes).toString('hex');
  }

  /**
   * Assina uma mensagem com a chave privada
   * @param {String} message - Mensagem a ser assinada
   * @param {String} privateKey - Chave privada em formato hex
   * @returns {String} Assinatura em formato hex
   */
  async sign(message, privateKey) {
    if (!this.initialized) await this.initialize();
    
    const privKey = Buffer.from(privateKey, 'hex');
    const messageBuffer = Buffer.from(message);
    
    const signature = sodium.crypto_sign_detached(messageBuffer, privKey);
    return Buffer.from(signature).toString('hex');
  }

  /**
   * Verifica uma assinatura com a chave pública
   * @param {String} message - Mensagem original
   * @param {String} signature - Assinatura em formato hex
   * @param {String} publicKey - Chave pública em formato hex
   * @returns {Boolean} Verdadeiro se a assinatura for válida
   */
  async verify(message, signature, publicKey) {
    if (!this.initialized) await this.initialize();
    
    const pubKey = Buffer.from(publicKey, 'hex');
    const messageBuffer = Buffer.from(message);
    const signatureBuffer = Buffer.from(signature, 'hex');
    
    return sodium.crypto_sign_verify_detached(signatureBuffer, messageBuffer, pubKey);
  }

  /**
   * Criptografa uma mensagem para um destinatário específico
   * @param {String} message - Mensagem a ser criptografada
   * @param {String} recipientPublicKey - Chave pública do destinatário em formato hex
   * @returns {Object} Mensagem criptografada e nonce
   */
  async encrypt(message, recipientPublicKey) {
    if (!this.initialized) await this.initialize();
    
    const pubKey = Buffer.from(recipientPublicKey, 'hex');
    const messageBuffer = Buffer.from(message);
    
    // Gerar um nonce aleatório
    const nonce = sodium.randombytes_buf(sodium.crypto_box_NONCEBYTES);
    
    // Gerar um par de chaves efêmero para o remetente
    const ephemeralKeyPair = sodium.crypto_box_keypair();
    
    // Criptografar a mensagem
    const ciphertext = sodium.crypto_box_easy(
      messageBuffer,
      nonce,
      pubKey,
      ephemeralKeyPair.privateKey
    );
    
    return {
      ciphertext: Buffer.from(ciphertext).toString('hex'),
      nonce: Buffer.from(nonce).toString('hex'),
      ephemeralPublicKey: Buffer.from(ephemeralKeyPair.publicKey).toString('hex')
    };
  }

  /**
   * Descriptografa uma mensagem com a chave privada do destinatário
   * @param {String} ciphertext - Mensagem criptografada em formato hex
   * @param {String} nonce - Nonce em formato hex
   * @param {String} ephemeralPublicKey - Chave pública efêmera do remetente em formato hex
   * @param {String} privateKey - Chave privada do destinatário em formato hex
   * @returns {String} Mensagem descriptografada
   */
  async decrypt(ciphertext, nonce, ephemeralPublicKey, privateKey) {
    if (!this.initialized) await this.initialize();
    
    const ciphertextBuffer = Buffer.from(ciphertext, 'hex');
    const nonceBuffer = Buffer.from(nonce, 'hex');
    const ephemPubKey = Buffer.from(ephemeralPublicKey, 'hex');
    const privKey = Buffer.from(privateKey, 'hex');
    
    const decrypted = sodium.crypto_box_open_easy(
      ciphertextBuffer,
      nonceBuffer,
      ephemPubKey,
      privKey
    );
    
    return Buffer.from(decrypted).toString();
  }
}

module.exports = IdentityManager;
