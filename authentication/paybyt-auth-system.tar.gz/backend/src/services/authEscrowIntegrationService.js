const AuthenticationAPI = require('../../api/authenticationAPI');
const EscrowService = require('../escrowService');

/**
 * Serviço de integração entre o sistema de autenticação anônima e o sistema de escrow multisig
 * 
 * Este módulo conecta o sistema de autenticação anônima com o sistema de escrow multisig,
 * permitindo que os usuários utilizem suas identidades anônimas para criar e gerenciar escrows.
 */
class AuthEscrowIntegrationService {
  /**
   * Inicializa o serviço de integração
   * @param {Object} options - Opções de configuração
   */
  constructor(options = {}) {
    this.authAPI = new AuthenticationAPI(options);
    this.escrowService = new EscrowService(options);
  }

  /**
   * Inicializa os componentes necessários
   */
  async initialize() {
    await this.authAPI.initialize();
    await this.escrowService.initialize();
  }

  /**
   * Cria um novo escrow usando uma identidade anônima
   * @param {Object} escrowData - Dados do escrow a ser criado
   * @param {String} identityId - ID da identidade anônima
   * @param {String} privateKey - Chave privada da identidade anônima
   * @returns {Object} Escrow criado
   */
  async createEscrowWithAnonymousIdentity(escrowData, identityId, privateKey) {
    try {
      // Verificar se a identidade é válida
      const isValid = await this.verifyAnonymousIdentity(identityId, privateKey);
      if (!isValid) {
        throw new Error('Identidade anônima inválida');
      }

      // Adicionar a identidade anônima aos dados do escrow
      const escrowWithIdentity = {
        ...escrowData,
        creatorIdentityId: identityId,
        isAnonymous: true
      };

      // Criar o escrow
      const escrow = await this.escrowService.createEscrow(escrowWithIdentity);

      return escrow;
    } catch (error) {
      console.error('Erro ao criar escrow com identidade anônima:', error);
      throw error;
    }
  }

  /**
   * Verifica se uma identidade anônima é válida
   * @param {String} identityId - ID da identidade anônima
   * @param {String} privateKey - Chave privada da identidade anônima
   * @returns {Boolean} Verdadeiro se a identidade for válida
   */
  async verifyAnonymousIdentity(identityId, privateKey) {
    try {
      // Gerar um desafio
      const challenge = await this.authAPI.generateChallenge(identityId);

      // Assinar o desafio com a chave privada
      const signature = await this.authAPI.identityManager.sign(
        challenge.challenge,
        privateKey
      );

      // Obter a chave pública a partir da chave privada
      // Em uma implementação real, isso seria feito de forma mais segura
      const keyPair = await this.authAPI.identityManager.generateKeyPair();
      const publicKey = keyPair.publicKey;

      // Verificar a assinatura
      const isValid = await this.authAPI.identityManager.verify(
        challenge.challenge,
        signature,
        publicKey
      );

      return isValid;
    } catch (error) {
      console.error('Erro ao verificar identidade anônima:', error);
      return false;
    }
  }

  /**
   * Obtém os escrows associados a uma identidade anônima
   * @param {String} identityId - ID da identidade anônima
   * @returns {Array} Lista de escrows
   */
  async getEscrowsByAnonymousIdentity(identityId) {
    try {
      // Buscar escrows onde a identidade anônima é o criador
      const escrows = await this.escrowService.getEscrowsByFilter({
        creatorIdentityId: identityId,
        isAnonymous: true
      });

      return escrows;
    } catch (error) {
      console.error('Erro ao obter escrows por identidade anônima:', error);
      throw error;
    }
  }

  /**
   * Confirma a entrega de um escrow usando uma identidade anônima
   * @param {String} escrowId - ID do escrow
   * @param {String} identityId - ID da identidade anônima
   * @param {String} privateKey - Chave privada da identidade anônima
   * @returns {Object} Resultado da confirmação
   */
  async confirmEscrowDeliveryWithAnonymousIdentity(escrowId, identityId, privateKey) {
    try {
      // Verificar se a identidade é válida
      const isValid = await this.verifyAnonymousIdentity(identityId, privateKey);
      if (!isValid) {
        throw new Error('Identidade anônima inválida');
      }

      // Verificar se o escrow pertence à identidade anônima
      const escrow = await this.escrowService.getEscrowById(escrowId);
      if (!escrow || escrow.creatorIdentityId !== identityId) {
        throw new Error('Escrow não encontrado ou não pertence a esta identidade');
      }

      // Confirmar a entrega
      const result = await this.escrowService.confirmDelivery(escrowId);

      return result;
    } catch (error) {
      console.error('Erro ao confirmar entrega com identidade anônima:', error);
      throw error;
    }
  }

  /**
   * Libera os fundos de um escrow usando uma identidade anônima
   * @param {String} escrowId - ID do escrow
   * @param {String} identityId - ID da identidade anônima
   * @param {String} privateKey - Chave privada da identidade anônima
   * @returns {Object} Resultado da liberação
   */
  async releaseEscrowFundsWithAnonymousIdentity(escrowId, identityId, privateKey) {
    try {
      // Verificar se a identidade é válida
      const isValid = await this.verifyAnonymousIdentity(identityId, privateKey);
      if (!isValid) {
        throw new Error('Identidade anônima inválida');
      }

      // Verificar se o escrow pertence à identidade anônima
      const escrow = await this.escrowService.getEscrowById(escrowId);
      if (!escrow || escrow.creatorIdentityId !== identityId) {
        throw new Error('Escrow não encontrado ou não pertence a esta identidade');
      }

      // Liberar os fundos
      const result = await this.escrowService.releaseFunds(escrowId);

      return result;
    } catch (error) {
      console.error('Erro ao liberar fundos com identidade anônima:', error);
      throw error;
    }
  }

  /**
   * Abre uma disputa em um escrow usando uma identidade anônima
   * @param {String} escrowId - ID do escrow
   * @param {String} identityId - ID da identidade anônima
   * @param {String} privateKey - Chave privada da identidade anônima
   * @param {String} reason - Motivo da disputa
   * @returns {Object} Resultado da abertura da disputa
   */
  async openEscrowDisputeWithAnonymousIdentity(escrowId, identityId, privateKey, reason) {
    try {
      // Verificar se a identidade é válida
      const isValid = await this.verifyAnonymousIdentity(identityId, privateKey);
      if (!isValid) {
        throw new Error('Identidade anônima inválida');
      }

      // Verificar se o escrow pertence à identidade anônima
      const escrow = await this.escrowService.getEscrowById(escrowId);
      if (!escrow || escrow.creatorIdentityId !== identityId) {
        throw new Error('Escrow não encontrado ou não pertence a esta identidade');
      }

      // Abrir a disputa
      const result = await this.escrowService.openDispute(escrowId, reason);

      return result;
    } catch (error) {
      console.error('Erro ao abrir disputa com identidade anônima:', error);
      throw error;
    }
  }
}

module.exports = AuthEscrowIntegrationService;
