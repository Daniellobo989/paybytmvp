const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../src/index');

describe('Sistema de Autenticação Anônima - Testes de API', () => {
  // Testes para a API de autenticação
  describe('API de Autenticação', () => {
    let identityId;
    let challenge;
    let token;

    // Teste de criação de identidade
    test('Deve criar uma nova identidade anônima', async () => {
      const response = await request(app)
        .post('/api/auth/identity')
        .expect(200);

      expect(response.body).toHaveProperty('identityId');
      expect(response.body).toHaveProperty('publicKey');
      expect(response.body).toHaveProperty('privateKey');
      
      identityId = response.body.identityId;
    });

    // Teste de geração de desafio
    test('Deve gerar um desafio para uma identidade existente', async () => {
      const response = await request(app)
        .post('/api/auth/challenge')
        .send({ identityId })
        .expect(200);

      expect(response.body).toHaveProperty('challenge');
      challenge = response.body.challenge;
    });

    // Teste de verificação de assinatura
    test('Deve verificar a assinatura e retornar um token', async () => {
      // Simular a assinatura do desafio
      // Em um teste real, isso seria feito com a chave privada real
      const signature = 'simulated_signature';
      const publicKey = 'simulated_public_key';

      const response = await request(app)
        .post('/api/auth/verify')
        .send({
          identityId,
          challenge,
          signature,
          publicKey
        })
        .expect(200);

      expect(response.body).toHaveProperty('token');
      token = response.body.token;
    });

    // Teste de verificação de token
    test('Deve verificar se um token é válido', async () => {
      const response = await request(app)
        .get('/api/auth/verify-token')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(response.body).toHaveProperty('valid', true);
    });
  });

  // Testes para a API de integração
  describe('API de Integração Auth-Escrow', () => {
    let identityId = 'test_identity_id';
    let privateKey = 'test_private_key';
    let escrowId;

    // Teste de criação de escrow com identidade anônima
    test('Deve criar um novo escrow usando uma identidade anônima', async () => {
      const escrowData = {
        title: 'Teste de Escrow',
        description: 'Escrow para teste de integração',
        amount: 0.001,
        recipientAddress: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'
      };

      const response = await request(app)
        .post('/api/integration/escrow')
        .send({
          escrowData,
          identityId,
          privateKey
        })
        .expect(200);

      expect(response.body).toHaveProperty('id');
      expect(response.body).toHaveProperty('title', escrowData.title);
      expect(response.body).toHaveProperty('creatorIdentityId', identityId);
      
      escrowId = response.body.id;
    });

    // Teste de obtenção de escrows por identidade anônima
    test('Deve obter os escrows associados a uma identidade anônima', async () => {
      const response = await request(app)
        .get(`/api/integration/escrow/${identityId}`)
        .expect(200);

      expect(Array.isArray(response.body)).toBe(true);
      expect(response.body.length).toBeGreaterThan(0);
      expect(response.body[0]).toHaveProperty('creatorIdentityId', identityId);
    });

    // Teste de confirmação de entrega com identidade anônima
    test('Deve confirmar a entrega de um escrow usando uma identidade anônima', async () => {
      const response = await request(app)
        .post(`/api/integration/escrow/${escrowId}/confirm`)
        .send({
          identityId,
          privateKey
        })
        .expect(200);

      expect(response.body).toHaveProperty('status', 'delivered');
    });

    // Teste de liberação de fundos com identidade anônima
    test('Deve liberar os fundos de um escrow usando uma identidade anônima', async () => {
      const response = await request(app)
        .post(`/api/integration/escrow/${escrowId}/release`)
        .send({
          identityId,
          privateKey
        })
        .expect(200);

      expect(response.body).toHaveProperty('status', 'completed');
    });

    // Teste de abertura de disputa com identidade anônima
    test('Deve abrir uma disputa em um escrow usando uma identidade anônima', async () => {
      // Criar um novo escrow para testar a disputa
      const escrowData = {
        title: 'Teste de Disputa',
        description: 'Escrow para teste de disputa',
        amount: 0.001,
        recipientAddress: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'
      };

      const createResponse = await request(app)
        .post('/api/integration/escrow')
        .send({
          escrowData,
          identityId,
          privateKey
        });

      const newEscrowId = createResponse.body.id;

      const response = await request(app)
        .post(`/api/integration/escrow/${newEscrowId}/dispute`)
        .send({
          identityId,
          privateKey,
          reason: 'Teste de disputa'
        })
        .expect(200);

      expect(response.body).toHaveProperty('status', 'disputed');
    });
  });

  // Limpar recursos após os testes
  afterAll(async () => {
    await mongoose.connection.close();
  });
});
