# Guia de Instalação - Sistema de Autenticação Anônima do PayByt

Este guia fornece instruções detalhadas para instalar, configurar e executar o Sistema de Autenticação Anônima do PayByt em ambientes de desenvolvimento e produção.

## Pré-requisitos

Antes de começar, certifique-se de que seu sistema atende aos seguintes requisitos:

- Node.js (versão 16.x ou superior)
- MongoDB (versão 4.4 ou superior)
- NPM (versão 8.x ou superior)
- Git

## Instalação

### 1. Clone o Repositório

```bash
git clone https://github.com/Daniellobo989/paybytmvp.git
cd paybytmvp/paybyt-auth
```

### 2. Instale as Dependências do Backend

```bash
cd backend
npm install
```

### 3. Instale as Dependências do Frontend

```bash
cd ../frontend
npm install
```

## Configuração

### 1. Configuração do Backend

Crie um arquivo `.env` na pasta `backend` com as seguintes variáveis:

```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/paybyt-auth
JWT_SECRET=seu_jwt_secret_seguro
NODE_ENV=development
BITCOIN_NETWORK=testnet
```

Substitua `seu_jwt_secret_seguro` por uma string aleatória e segura.

### 2. Configuração do MongoDB

Certifique-se de que o MongoDB está em execução:

```bash
# Verificar status do MongoDB
sudo systemctl status mongodb

# Iniciar MongoDB se não estiver em execução
sudo systemctl start mongodb
```

### 3. Configuração do Frontend

Crie um arquivo `.env` na pasta `frontend` com as seguintes variáveis:

```
VITE_API_URL=http://localhost:5000/api
```

## Execução em Ambiente de Desenvolvimento

### 1. Iniciar o Backend

```bash
cd backend
npm run dev
```

O servidor backend será iniciado na porta 5000 (ou na porta especificada no arquivo `.env`).

### 2. Iniciar o Frontend

Em outro terminal:

```bash
cd frontend
npm run dev
```

O servidor de desenvolvimento do frontend será iniciado na porta 3000 e abrirá automaticamente no seu navegador padrão.

## Execução de Testes

### 1. Testes do Backend

```bash
cd backend
npm test
```

### 2. Testes do Frontend

```bash
cd frontend
npm test
```

## Build para Produção

### 1. Build do Backend

```bash
cd backend
npm run build
```

### 2. Build do Frontend

```bash
cd frontend
npm run build
```

Os arquivos de build do frontend serão gerados na pasta `dist`.

## Implantação em Produção

### 1. Configuração para Produção

Atualize o arquivo `.env` do backend para produção:

```
PORT=5000
MONGODB_URI=sua_uri_mongodb_producao
JWT_SECRET=seu_jwt_secret_producao
NODE_ENV=production
BITCOIN_NETWORK=mainnet
```

### 2. Implantação do Backend

Para implantar o backend em um servidor:

```bash
cd backend
npm run build
npm run start
```

Para manter o servidor em execução, recomendamos o uso de um gerenciador de processos como PM2:

```bash
npm install -g pm2
pm2 start dist/index.js --name paybyt-auth-backend
```

### 3. Implantação do Frontend

Existem várias opções para implantar o frontend:

#### Opção 1: Servidor Web (Nginx)

Copie os arquivos da pasta `frontend/dist` para o diretório do seu servidor web e configure o Nginx:

```nginx
server {
    listen 80;
    server_name seu-dominio.com;

    root /caminho/para/frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### Opção 2: Serviços de Hospedagem Estática

Você pode implantar o frontend em serviços como:

- GitHub Pages
- Netlify
- Vercel
- Firebase Hosting

Para o GitHub Pages:

1. Crie um repositório no GitHub
2. Adicione os arquivos da pasta `dist` ao repositório
3. Configure o GitHub Pages para usar a branch principal

## Integração com o Sistema de Escrow Multisig

Para integrar o Sistema de Autenticação Anônima com o Sistema de Escrow Multisig existente:

1. Certifique-se de que o Sistema de Escrow Multisig está instalado e configurado
2. Configure as variáveis de ambiente para apontar para a API do Sistema de Escrow:

```
ESCROW_API_URL=http://localhost:5001/api
```

3. Reinicie o backend para aplicar as alterações

## Solução de Problemas

### Problemas de Conexão com MongoDB

Se você encontrar problemas de conexão com o MongoDB:

```bash
# Verifique se o MongoDB está em execução
sudo systemctl status mongodb

# Verifique os logs do MongoDB
sudo journalctl -u mongodb

# Verifique a configuração do MongoDB
cat /etc/mongodb.conf
```

### Problemas com o Backend

Se o backend não iniciar corretamente:

1. Verifique os logs de erro
2. Certifique-se de que todas as dependências estão instaladas
3. Verifique se as variáveis de ambiente estão configuradas corretamente

### Problemas com o Frontend

Se o frontend não funcionar corretamente:

1. Verifique se a URL da API está configurada corretamente
2. Limpe o cache do navegador
3. Verifique os logs de erro no console do navegador

## Atualizações

Para atualizar o sistema para uma nova versão:

1. Faça backup dos arquivos de configuração
2. Faça pull das alterações mais recentes do repositório
3. Instale as novas dependências
4. Execute os testes para garantir que tudo está funcionando corretamente
5. Faça o build e reimplante o sistema

## Suporte

Se você encontrar problemas durante a instalação ou configuração, entre em contato com a equipe de suporte do PayByt ou consulte a documentação técnica para obter mais informações.
