# Documentação de Implantação - Sistema de Autenticação Anônima do PayByt

Este documento descreve o processo de implantação do Sistema de Autenticação Anônima do PayByt no GitHub Pages com backend hospedado no GitHub usando GitHub Actions.

## Visão Geral da Implantação

A implantação consiste em:

1. Frontend estático hospedado no GitHub Pages
2. Backend hospedado usando GitHub Actions e GitHub Codespaces
3. Sistema de implantação gradual com convites para usuários iniciais

## Configuração do Repositório GitHub

### Estrutura do Repositório

```
paybyt-auth/
├── .github/
│   └── workflows/
│       ├── deploy-frontend.yml  # Workflow para implantação do frontend
│       └── deploy-backend.yml   # Workflow para implantação do backend
├── backend/                     # Código do backend
├── frontend/                    # Código do frontend
└── docs/                        # Documentação
```

### Configuração do GitHub Pages

1. No repositório GitHub, vá para "Settings" > "Pages"
2. Em "Source", selecione a branch "gh-pages"
3. Clique em "Save"

## Implantação do Frontend

### Preparação do Frontend para GitHub Pages

1. Configurar o arquivo `vite.config.js` para suportar GitHub Pages:

```javascript
export default defineConfig({
  plugins: [react()],
  base: '/paybyt-auth/',  // Nome do repositório
  build: {
    outDir: 'dist',
    sourcemap: true
  }
});
```

2. Adicionar arquivo `404.html` para suportar rotas do React Router:

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>PayByt - Autenticação Anônima</title>
  <script type="text/javascript">
    var pathSegmentsToKeep = 1;
    var l = window.location;
    l.replace(
      l.protocol + '//' + l.hostname + (l.port ? ':' + l.port : '') +
      l.pathname.split('/').slice(0, 1 + pathSegmentsToKeep).join('/') + '/?/' +
      l.pathname.slice(1).split('/').slice(pathSegmentsToKeep).join('/').replace(/&/g, '~and~') +
      (l.search ? '&' + l.search.slice(1).replace(/&/g, '~and~') : '') +
      l.hash
    );
  </script>
</head>
<body>
  Redirecionando...
</body>
</html>
```

3. Modificar `index.html` para suportar redirecionamento:

```html
<script type="text/javascript">
  (function(l) {
    if (l.search[1] === '/' ) {
      var decoded = l.search.slice(1).split('&').map(function(s) { 
        return s.replace(/~and~/g, '&')
      }).join('?');
      window.history.replaceState(null, null,
          l.pathname.slice(0, -1) + decoded + l.hash
      );
    }
  }(window.location))
</script>
```

### Workflow de Implantação do Frontend

Criar arquivo `.github/workflows/deploy-frontend.yml`:

```yaml
name: Deploy Frontend to GitHub Pages

on:
  push:
    branches: [ main ]
    paths:
      - 'frontend/**'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v2

      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '16'

      - name: Install Dependencies
        run: |
          cd frontend
          npm install

      - name: Build
        run: |
          cd frontend
          npm run build

      - name: Deploy to GitHub Pages
        uses: JamesIves/github-pages-deploy-action@4.1.4
        with:
          branch: gh-pages
          folder: frontend/dist
```

## Implantação do Backend

### Preparação do Backend para GitHub

1. Configurar o backend para usar variáveis de ambiente do GitHub:

```javascript
// backend/src/config.js
module.exports = {
  port: process.env.PORT || 5000,
  mongoUri: process.env.MONGODB_URI || 'mongodb://localhost:27017/paybyt-auth',
  jwtSecret: process.env.JWT_SECRET || 'development_secret',
  nodeEnv: process.env.NODE_ENV || 'development',
  bitcoinNetwork: process.env.BITCOIN_NETWORK || 'testnet',
  allowedOrigins: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : ['http://localhost:3000']
};
```

2. Adicionar arquivo `Procfile` para serviços de hospedagem:

```
web: node src/index.js
```

### Workflow de Implantação do Backend

Criar arquivo `.github/workflows/deploy-backend.yml`:

```yaml
name: Deploy Backend

on:
  push:
    branches: [ main ]
    paths:
      - 'backend/**'

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v2

      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '16'

      - name: Install Dependencies
        run: |
          cd backend
          npm install

      - name: Run Tests
        run: |
          cd backend
          npm test

      - name: Deploy to GitHub Codespaces
        uses: actions/github-script@v5
        with:
          script: |
            const { repo, owner } = context.repo;
            const result = await github.rest.codespaces.createWithRepoForAuthenticatedUser({
              repository_id: context.payload.repository.id,
              ref: context.sha,
              machine: 'basicLinux32gb',
              location: 'WestUs2',
              post_create_command: 'cd backend && npm install && npm start'
            });
            console.log(`Codespace created: ${result.data.html_url}`);
```

## Sistema de Implantação Gradual

### Implementação do Sistema de Convites

1. Adicionar modelo de convite ao banco de dados:

```javascript
// backend/src/models/inviteModel.js
const mongoose = require('mongoose');

const inviteSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true
  },
  email: {
    type: String,
    required: false
  },
  isUsed: {
    type: Boolean,
    default: false
  },
  usedBy: {
    type: String,
    required: false
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: '30d' // Convites expiram após 30 dias
  }
});

module.exports = mongoose.model('Invite', inviteSchema);
```

2. Adicionar rotas para gerenciamento de convites:

```javascript
// backend/src/routes/inviteRoutes.js
const express = require('express');
const router = express.Router();
const Invite = require('../models/inviteModel');
const { v4: uuidv4 } = require('uuid');

// Gerar novo convite (protegido por autenticação de admin)
router.post('/generate', async (req, res) => {
  try {
    const { email } = req.body;
    
    const invite = new Invite({
      code: uuidv4(),
      email
    });
    
    await invite.save();
    
    res.json({ code: invite.code });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao gerar convite' });
  }
});

// Verificar convite
router.post('/verify', async (req, res) => {
  try {
    const { code } = req.body;
    
    const invite = await Invite.findOne({ code, isUsed: false });
    
    if (!invite) {
      return res.status(404).json({ valid: false, error: 'Convite inválido ou já utilizado' });
    }
    
    res.json({ valid: true });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao verificar convite' });
  }
});

// Usar convite
router.post('/use', async (req, res) => {
  try {
    const { code, identityId } = req.body;
    
    const invite = await Invite.findOne({ code, isUsed: false });
    
    if (!invite) {
      return res.status(404).json({ success: false, error: 'Convite inválido ou já utilizado' });
    }
    
    invite.isUsed = true;
    invite.usedBy = identityId;
    await invite.save();
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao utilizar convite' });
  }
});

module.exports = router;
```

3. Modificar o frontend para solicitar código de convite:

```jsx
// frontend/src/pages/AuthPage.tsx (modificado)
// Adicionar verificação de convite antes de permitir a criação de identidade

const [inviteCode, setInviteCode] = useState('');
const [isInviteValid, setIsInviteValid] = useState(false);

const verifyInvite = async () => {
  try {
    setIsLoading(true);
    setError(null);
    
    const response = await axios.post('/api/invite/verify', {
      code: inviteCode
    });
    
    if (response.data.valid) {
      setIsInviteValid(true);
    } else {
      setError('Código de convite inválido');
    }
  } catch (err) {
    setError('Erro ao verificar convite: ' + (err.response?.data?.error || err.message));
  } finally {
    setIsLoading(false);
  }
};

// Modificar a função generateIdentity para usar o convite
const generateIdentity = async () => {
  try {
    // ... código existente ...
    
    // Usar o convite
    await axios.post('/api/invite/use', {
      code: inviteCode,
      identityId: newIdentity.identityId
    });
    
    // ... resto do código existente ...
  } catch (err) {
    // ... código existente ...
  }
};

// Adicionar campo de entrada para código de convite no formulário
{!isInviteValid && (
  <div>
    <p className="mb-4">
      Este sistema está em fase de implantação gradual. Por favor, insira seu código de convite para continuar.
    </p>
    <div className="flex space-x-2">
      <input
        type="text"
        value={inviteCode}
        onChange={(e) => setInviteCode(e.target.value)}
        placeholder="Código de convite"
        className="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
      />
      <button
        onClick={verifyInvite}
        disabled={isLoading}
        className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
      >
        Verificar
      </button>
    </div>
  </div>
)}
```

## Configuração de Variáveis de Ambiente no GitHub

1. No repositório GitHub, vá para "Settings" > "Secrets" > "Actions"
2. Adicione as seguintes variáveis de ambiente:
   - `MONGODB_URI`: URI de conexão com o MongoDB
   - `JWT_SECRET`: Chave secreta para assinatura de tokens JWT
   - `NODE_ENV`: "production"
   - `BITCOIN_NETWORK`: "testnet" (ou "mainnet" para produção)
   - `ALLOWED_ORIGINS`: Lista de origens permitidas, separadas por vírgula

## Monitoramento e Logs

1. Configurar logs no backend:

```javascript
// backend/src/utils/logger.js
const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

module.exports = logger;
```

2. Integrar logs no aplicativo:

```javascript
// backend/src/index.js
const logger = require('./utils/logger');

// Middleware de log
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.url}`);
  next();
});

// Log de erros
app.use((err, req, res, next) => {
  logger.error(`${err.status || 500} - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`);
  res.status(err.status || 500).json({ error: err.message });
});
```

## Instruções para Administradores

### Geração de Convites

Para gerar novos convites para usuários:

1. Acesse a API de administração com credenciais de administrador
2. Use o endpoint `/api/invite/generate` para criar novos códigos de convite
3. Distribua os códigos para os usuários selecionados

### Monitoramento de Uso

Para monitorar o uso do sistema:

1. Verifique os logs do aplicativo para identificar problemas
2. Monitore o banco de dados para verificar o crescimento de usuários
3. Acompanhe o uso de convites para controlar a taxa de adoção

## Plano de Contingência

Em caso de problemas durante a implantação:

1. Reverta para a versão anterior usando o histórico do GitHub
2. Verifique os logs para identificar a causa do problema
3. Corrija o problema e reimplante
4. Comunique os usuários afetados, se necessário

## Próximos Passos

Após a implantação inicial bem-sucedida:

1. Coletar feedback dos usuários iniciais
2. Corrigir problemas identificados
3. Expandir gradualmente o número de usuários
4. Implementar melhorias baseadas no feedback
5. Preparar para implantação completa
