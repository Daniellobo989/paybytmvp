# Configuração do Ambiente de Desenvolvimento

Este documento descreve a configuração do ambiente de desenvolvimento para o Sistema de Autenticação Anônima do PayByt.

## Requisitos de Software

- Node.js (v16 ou superior)
- npm (v7 ou superior)
- MongoDB (v4.4 ou superior)
- Git

## Estrutura do Projeto

```
paybyt-auth/
├── docs/                    # Documentação
├── research/                # Pesquisas e análises de tecnologias
├── src/                     # Código-fonte
│   ├── core/                # Componentes principais
│   ├── crypto/              # Implementações criptográficas
│   ├── zkp/                 # Implementações de Zero-knowledge proofs
│   ├── api/                 # APIs para integração
│   └── ui/                  # Interface de usuário
└── tests/                   # Testes automatizados
```

## Dependências Principais

### Backend

```json
{
  "dependencies": {
    "express": "^4.17.1",
    "mongoose": "^6.0.12",
    "jsonwebtoken": "^8.5.1",
    "libsodium-wrappers": "^0.7.9",
    "snarkjs": "^0.4.10",
    "circomlib": "^2.0.3",
    "bitcoinjs-lib": "^6.0.0",
    "cors": "^2.8.5",
    "dotenv": "^10.0.0",
    "helmet": "^4.6.0"
  },
  "devDependencies": {
    "jest": "^27.3.1",
    "nodemon": "^2.0.14",
    "eslint": "^8.1.0",
    "supertest": "^6.1.6"
  }
}
```

### Frontend

```json
{
  "dependencies": {
    "react": "^17.0.2",
    "react-dom": "^17.0.2",
    "react-router-dom": "^6.0.0",
    "axios": "^0.24.0",
    "libsodium-wrappers": "^0.7.9",
    "snarkjs": "^0.4.10",
    "qrcode.react": "^1.0.1",
    "tailwindcss": "^2.2.19"
  },
  "devDependencies": {
    "@testing-library/react": "^12.1.2",
    "@testing-library/jest-dom": "^5.14.1",
    "vite": "^2.6.13",
    "eslint": "^8.1.0"
  }
}
```

## Configuração do Ambiente

### 1. Configuração do Backend

1. Criar arquivo `package.json`:

```json
{
  "name": "paybyt-auth-backend",
  "version": "0.1.0",
  "description": "Backend para o Sistema de Autenticação Anônima do PayByt",
  "main": "src/index.js",
  "scripts": {
    "start": "node src/index.js",
    "dev": "nodemon src/index.js",
    "test": "jest"
  },
  "dependencies": {
    "express": "^4.17.1",
    "mongoose": "^6.0.12",
    "jsonwebtoken": "^8.5.1",
    "libsodium-wrappers": "^0.7.9",
    "snarkjs": "^0.4.10",
    "circomlib": "^2.0.3",
    "bitcoinjs-lib": "^6.0.0",
    "cors": "^2.8.5",
    "dotenv": "^10.0.0",
    "helmet": "^4.6.0"
  },
  "devDependencies": {
    "jest": "^27.3.1",
    "nodemon": "^2.0.14",
    "eslint": "^8.1.0",
    "supertest": "^6.1.6"
  }
}
```

2. Criar arquivo `.env`:

```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/paybyt-auth
JWT_SECRET=your_jwt_secret_key
NODE_ENV=development
```

3. Criar estrutura básica do servidor:

```javascript
// src/index.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const mongoose = require('mongoose');

// Inicializar app
const app = express();

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Conectar ao MongoDB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('Conectado ao MongoDB'))
.catch(err => console.error('Erro ao conectar ao MongoDB:', err));

// Rotas
app.get('/', (req, res) => {
  res.json({ message: 'API do Sistema de Autenticação Anônima do PayByt' });
});

// Iniciar servidor
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
```

### 2. Configuração do Frontend

1. Criar aplicação React com Vite:

```bash
npm create vite@latest paybyt-auth-frontend -- --template react-ts
cd paybyt-auth-frontend
npm install
```

2. Instalar dependências adicionais:

```bash
npm install react-router-dom axios libsodium-wrappers snarkjs qrcode.react tailwindcss
```

3. Configurar Tailwind CSS:

```bash
npx tailwindcss init
```

4. Criar arquivo `tailwind.config.js`:

```javascript
module.exports = {
  purge: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: false,
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#002D72',
          dark: '#001d4a',
          light: '#1a4a8f'
        },
        bitcoin: {
          DEFAULT: '#F7931A',
          dark: '#d97908',
          light: '#f9a94d'
        }
      }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
```

5. Atualizar `src/index.css`:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### 3. Configuração do Ambiente de Desenvolvimento ZKP

1. Instalar circom:

```bash
npm install -g circom
```

2. Criar diretório para circuitos:

```bash
mkdir -p src/zkp/circuits
```

3. Criar um circuito de exemplo para prova de identidade:

```
// src/zkp/circuits/identity.circom
pragma circom 2.0.0;

include "../node_modules/circomlib/circuits/poseidon.circom";

template IdentityProof() {
    signal input identitySecret;
    signal input identityCommitment;
    
    component hasher = Poseidon(1);
    hasher.inputs[0] <== identitySecret;
    
    // Verificar se o commitment corresponde ao hash do segredo
    identityCommitment === hasher.out;
}

component main = IdentityProof();
```

## Scripts de Inicialização

### Backend

```bash
#!/bin/bash
# start-backend.sh

cd backend
npm install
npm run dev
```

### Frontend

```bash
#!/bin/bash
# start-frontend.sh

cd frontend
npm install
npm run dev
```

## Próximos Passos

1. Implementar modelos de dados para o MongoDB
2. Desenvolver os componentes de criptografia e ZKP
3. Criar APIs RESTful para autenticação anônima
4. Implementar interface de usuário para gerenciamento de identidades
5. Integrar com o marketplace PayByt existente
