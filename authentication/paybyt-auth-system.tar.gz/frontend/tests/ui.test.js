import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import AuthPage from '../src/pages/AuthPage';
import EscrowWithAuthPage from '../src/pages/EscrowWithAuthPage';

// Mock do axios
jest.mock('axios', () => ({
  post: jest.fn(() => Promise.resolve({ data: {} })),
  get: jest.fn(() => Promise.resolve({ data: [] })),
  defaults: {
    headers: {
      common: {}
    }
  }
}));

// Mock do libsodium-wrappers
jest.mock('libsodium-wrappers', () => ({
  ready: Promise.resolve(),
  from_hex: jest.fn(),
  from_string: jest.fn(),
  crypto_sign_detached: jest.fn(),
  to_hex: jest.fn()
}));

// Mock do localStorage
const localStorageMock = (() => {
  let store = {};
  return {
    getItem: jest.fn(key => store[key] || null),
    setItem: jest.fn((key, value) => {
      store[key] = value.toString();
    }),
    removeItem: jest.fn(key => {
      delete store[key];
    }),
    clear: jest.fn(() => {
      store = {};
    })
  };
})();
Object.defineProperty(window, 'localStorage', { value: localStorageMock });

describe('Sistema de Autenticação Anônima - Testes de Interface', () => {
  // Testes para a página de autenticação
  describe('Página de Autenticação', () => {
    beforeEach(() => {
      localStorageMock.clear();
    });

    test('Deve renderizar a página de autenticação inicial', () => {
      render(
        <BrowserRouter>
          <AuthPage />
        </BrowserRouter>
      );

      expect(screen.getByText(/Autenticação Anônima/i)).toBeInTheDocument();
      expect(screen.getByText(/Gerar Identidade Anônima/i)).toBeInTheDocument();
    });

    test('Deve mostrar a seção de identidade após gerar uma identidade', async () => {
      const mockIdentity = {
        identityId: 'test_id',
        publicKey: 'test_public_key',
        privateKey: 'test_private_key'
      };

      const axios = require('axios');
      axios.post.mockResolvedValueOnce({ data: mockIdentity });

      render(
        <BrowserRouter>
          <AuthPage />
        </BrowserRouter>
      );

      fireEvent.click(screen.getByText(/Gerar Identidade Anônima/i));

      await waitFor(() => {
        expect(screen.getByText(/Sua identidade anônima foi gerada com sucesso/i)).toBeInTheDocument();
        expect(screen.getByText(/ID da Identidade:/i)).toBeInTheDocument();
        expect(screen.getByText(/Chave Pública:/i)).toBeInTheDocument();
      });

      expect(localStorageMock.setItem).toHaveBeenCalledWith('anonymousIdentity', JSON.stringify(mockIdentity));
    });
  });

  // Testes para a página de escrow com autenticação
  describe('Página de Escrow com Autenticação', () => {
    beforeEach(() => {
      localStorageMock.clear();
    });

    test('Deve mostrar mensagem de autenticação necessária quando não autenticado', () => {
      render(
        <BrowserRouter>
          <EscrowWithAuthPage />
        </BrowserRouter>
      );

      expect(screen.getByText(/Autenticação Necessária/i)).toBeInTheDocument();
      expect(screen.getByText(/Você precisa estar autenticado com uma identidade anônima/i)).toBeInTheDocument();
    });

    test('Deve mostrar a lista de escrows quando autenticado', async () => {
      const mockIdentity = {
        identityId: 'test_id',
        publicKey: 'test_public_key',
        privateKey: 'test_private_key'
      };

      const mockEscrows = [
        {
          id: 'escrow_1',
          title: 'Teste Escrow 1',
          amount: 0.001,
          status: 'funded',
          createdAt: new Date().toISOString()
        }
      ];

      localStorageMock.setItem('anonymousIdentity', JSON.stringify(mockIdentity));
      localStorageMock.setItem('anonymousToken', 'test_token');

      const axios = require('axios');
      axios.get.mockResolvedValueOnce({ data: mockEscrows });

      render(
        <BrowserRouter>
          <EscrowWithAuthPage />
        </BrowserRouter>
      );

      await waitFor(() => {
        expect(screen.getByText(/Seus Escrows Anônimos/i)).toBeInTheDocument();
        expect(screen.getByText(/Teste Escrow 1/i)).toBeInTheDocument();
      });
    });

    test('Deve mostrar o formulário de criação de escrow ao clicar em Criar Novo Escrow', async () => {
      const mockIdentity = {
        identityId: 'test_id',
        publicKey: 'test_public_key',
        privateKey: 'test_private_key'
      };

      localStorageMock.setItem('anonymousIdentity', JSON.stringify(mockIdentity));
      localStorageMock.setItem('anonymousToken', 'test_token');

      const axios = require('axios');
      axios.get.mockResolvedValueOnce({ data: [] });

      render(
        <BrowserRouter>
          <EscrowWithAuthPage />
        </BrowserRouter>
      );

      await waitFor(() => {
        expect(screen.getByText(/Seus Escrows Anônimos/i)).toBeInTheDocument();
      });

      fireEvent.click(screen.getByText(/Criar Novo Escrow/i));

      expect(screen.getByText(/Criar Novo Escrow Anônimo/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Título/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Descrição/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Valor \(BTC\)/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Endereço do Destinatário/i)).toBeInTheDocument();
    });
  });
});
