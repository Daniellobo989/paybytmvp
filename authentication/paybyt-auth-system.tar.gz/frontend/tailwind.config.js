module.exports = {
  purge: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: false,
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#002D72',
          dark: '#001d4a',
          light: '#1a4a8f'
        },
        bitcoin: {
          DEFAULT: '#F7931A',
          dark: '#d97908',
          light: '#f9a94d'
        }
      }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
