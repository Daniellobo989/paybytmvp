import React, { useState, useEffect } from 'react';
import axios from 'axios';
import * as sodium from 'libsodium-wrappers';

const EscrowWithAuthPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [identity, setIdentity] = useState(null);
  const [escrows, setEscrows] = useState([]);
  const [error, setError] = useState(null);
  const [newEscrow, setNewEscrow] = useState({
    title: '',
    description: '',
    amount: '',
    recipientAddress: ''
  });
  const [activeTab, setActiveTab] = useState('list'); // list, create, detail
  const [selectedEscrow, setSelectedEscrow] = useState(null);

  // Inicializar libsodium
  useEffect(() => {
    const initSodium = async () => {
      await sodium.ready;
      console.log('Libsodium inicializado');
    };
    initSodium();
  }, []);

  // Verificar se já existe uma identidade no localStorage
  useEffect(() => {
    const storedIdentity = localStorage.getItem('anonymousIdentity');
    const storedToken = localStorage.getItem('anonymousToken');
    
    if (storedIdentity && storedToken) {
      const parsedIdentity = JSON.parse(storedIdentity);
      setIdentity(parsedIdentity);
      
      // Configurar o token para requisições
      axios.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`;
      
      // Carregar escrows da identidade
      loadEscrows(parsedIdentity.identityId);
    }
  }, []);

  // Carregar escrows da identidade
  const loadEscrows = async (identityId) => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await axios.get(`/api/integration/escrow/${identityId}`);
      setEscrows(response.data);
      
      console.log('Escrows carregados:', response.data);
    } catch (err) {
      setError('Erro ao carregar escrows: ' + (err.response?.data?.error || err.message));
      console.error('Erro ao carregar escrows:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Criar novo escrow
  const createEscrow = async (e) => {
    e.preventDefault();
    
    if (!identity) {
      setError('Você precisa estar autenticado para criar um escrow');
      return;
    }
    
    try {
      setIsLoading(true);
      setError(null);
      
      const escrowData = {
        title: newEscrow.title,
        description: newEscrow.description,
        amount: parseFloat(newEscrow.amount),
        recipientAddress: newEscrow.recipientAddress
      };
      
      const response = await axios.post('/api/integration/escrow', {
        escrowData,
        identityId: identity.identityId,
        privateKey: identity.privateKey
      });
      
      console.log('Escrow criado:', response.data);
      
      // Limpar formulário
      setNewEscrow({
        title: '',
        description: '',
        amount: '',
        recipientAddress: ''
      });
      
      // Recarregar escrows
      await loadEscrows(identity.identityId);
      
      // Voltar para a lista
      setActiveTab('list');
    } catch (err) {
      setError('Erro ao criar escrow: ' + (err.response?.data?.error || err.message));
      console.error('Erro ao criar escrow:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Confirmar entrega
  const confirmDelivery = async (escrowId) => {
    if (!identity) {
      setError('Você precisa estar autenticado para confirmar a entrega');
      return;
    }
    
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await axios.post(`/api/integration/escrow/${escrowId}/confirm`, {
        identityId: identity.identityId,
        privateKey: identity.privateKey
      });
      
      console.log('Entrega confirmada:', response.data);
      
      // Recarregar escrows
      await loadEscrows(identity.identityId);
      
      // Atualizar escrow selecionado
      if (selectedEscrow && selectedEscrow.id === escrowId) {
        setSelectedEscrow(response.data);
      }
    } catch (err) {
      setError('Erro ao confirmar entrega: ' + (err.response?.data?.error || err.message));
      console.error('Erro ao confirmar entrega:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Liberar fundos
  const releaseFunds = async (escrowId) => {
    if (!identity) {
      setError('Você precisa estar autenticado para liberar fundos');
      return;
    }
    
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await axios.post(`/api/integration/escrow/${escrowId}/release`, {
        identityId: identity.identityId,
        privateKey: identity.privateKey
      });
      
      console.log('Fundos liberados:', response.data);
      
      // Recarregar escrows
      await loadEscrows(identity.identityId);
      
      // Atualizar escrow selecionado
      if (selectedEscrow && selectedEscrow.id === escrowId) {
        setSelectedEscrow(response.data);
      }
    } catch (err) {
      setError('Erro ao liberar fundos: ' + (err.response?.data?.error || err.message));
      console.error('Erro ao liberar fundos:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Abrir disputa
  const openDispute = async (escrowId, reason) => {
    if (!identity) {
      setError('Você precisa estar autenticado para abrir uma disputa');
      return;
    }
    
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await axios.post(`/api/integration/escrow/${escrowId}/dispute`, {
        identityId: identity.identityId,
        privateKey: identity.privateKey,
        reason
      });
      
      console.log('Disputa aberta:', response.data);
      
      // Recarregar escrows
      await loadEscrows(identity.identityId);
      
      // Atualizar escrow selecionado
      if (selectedEscrow && selectedEscrow.id === escrowId) {
        setSelectedEscrow(response.data);
      }
    } catch (err) {
      setError('Erro ao abrir disputa: ' + (err.response?.data?.error || err.message));
      console.error('Erro ao abrir disputa:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Visualizar detalhes do escrow
  const viewEscrowDetails = (escrow) => {
    setSelectedEscrow(escrow);
    setActiveTab('detail');
  };

  // Formatar data
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Formatar status
  const formatStatus = (status) => {
    const statusMap = {
      created: 'Criado',
      funded: 'Financiado',
      delivered: 'Entregue',
      completed: 'Concluído',
      disputed: 'Em disputa',
      refunded: 'Reembolsado'
    };
    
    return statusMap[status] || status;
  };

  // Renderizar formulário de criação de escrow
  const renderCreateEscrowForm = () => {
    return (
      <div>
        <h2 className="text-xl font-bold text-primary mb-4">Criar Novo Escrow Anônimo</h2>
        
        <form onSubmit={createEscrow} className="space-y-4">
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="title">
              Título
            </label>
            <input
              id="title"
              type="text"
              value={newEscrow.title}
              onChange={(e) => setNewEscrow({...newEscrow, title: e.target.value})}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              required
            />
          </div>
          
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
              Descrição
            </label>
            <textarea
              id="description"
              value={newEscrow.description}
              onChange={(e) => setNewEscrow({...newEscrow, description: e.target.value})}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              rows="3"
              required
            />
          </div>
          
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="amount">
              Valor (BTC)
            </label>
            <input
              id="amount"
              type="number"
              step="0.00000001"
              value={newEscrow.amount}
              onChange={(e) => setNewEscrow({...newEscrow, amount: e.target.value})}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              required
            />
          </div>
          
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="recipientAddress">
              Endereço do Destinatário
            </label>
            <input
              id="recipientAddress"
              type="text"
              value={newEscrow.recipientAddress}
              onChange={(e) => setNewEscrow({...newEscrow, recipientAddress: e.target.value})}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              required
            />
          </div>
          
          <div className="flex space-x-4">
            <button
              type="submit"
              disabled={isLoading}
              className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              {isLoading ? 'Criando...' : 'Criar Escrow'}
            </button>
            
            <button
              type="button"
              onClick={() => setActiveTab('list')}
              className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    );
  };

  // Renderizar lista de escrows
  const renderEscrowList = () => {
    return (
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-primary">Seus Escrows Anônimos</h2>
          
          <button
            onClick={() => setActiveTab('create')}
            className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          >
            Criar Novo Escrow
          </button>
        </div>
        
        {escrows.length === 0 ? (
          <p className="text-gray-500">Nenhum escrow encontrado.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr className="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
                  <th className="py-3 px-6 text-left">ID</th>
                  <th className="py-3 px-6 text-left">Título</th>
                  <th className="py-3 px-6 text-right">Valor (BTC)</th>
                  <th className="py-3 px-6 text-left">Status</th>
                  <th className="py-3 px-6 text-left">Data</th>
                  <th className="py-3 px-6 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="text-gray-600 text-sm">
                {escrows.map((escrow) => (
                  <tr key={escrow.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-6 text-left whitespace-nowrap">
                      <span className="font-mono">{escrow.id.substring(0, 8)}...</span>
                    </td>
                    <td className="py-3 px-6 text-left">
                      {escrow.title}
                    </td>
                    <td className="py-3 px-6 text-right">
                      {escrow.amount.toFixed(8)}
                    </td>
                    <td className="py-3 px-6 text-left">
                      <span className={`py-1 px-3 rounded-full text-xs ${
                        escrow.status === 'completed' ? 'bg-green-200 text-green-800' :
                        escrow.status === 'disputed' ? 'bg-red-200 text-red-800' :
                        'bg-blue-200 text-blue-800'
                      }`}>
                        {formatStatus(escrow.status)}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-left">
                      {formatDate(escrow.createdAt)}
                    </td>
                    <td className="py-3 px-6 text-center">
                      <button
                        onClick={() => viewEscrowDetails(escrow)}
                        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded text-xs"
                      >
                        Detalhes
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  };

  // Renderizar detalhes do escrow
  const renderEscrowDetails = () => {
    if (!selectedEscrow) {
      return null;
    }
    
    return (
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-primary">Detalhes do Escrow</h2>
          
          <button
            onClick={() => setActiveTab('list')}
            className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          >
            Voltar para Lista
          </button>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6">
          <div className="mb-4">
            <h3 className="text-lg font-bold">{selectedEscrow.title}</h3>
            <p className="text-gray-600 mt-1">{selectedEscrow.description}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <p className="text-gray-600">ID do Escrow:</p>
              <p className="font-mono text-sm">{selectedEscrow.id}</p>
            </div>
            
            <div>
              <p className="text-gray-600">Status:</p>
              <span className={`py-1 px-3 rounded-full text-xs ${
                selectedEscrow.status === 'completed' ? 'bg-green-200 text-green-800' :
                selectedEscrow.status === 'disputed' ? 'bg-red-200 text-red-800' :
                'bg-blue-200 text-blue-800'
              }`}>
                {formatStatus(selectedEscrow.status)}
              </span>
            </div>
            
            <div>
              <p className="text-gray-600">Valor:</p>
              <p className="font-bold">{selectedEscrow.amount.toFixed(8)} BTC</p>
            </div>
            
            <div>
              <p className="text-gray-600">Data de Criação:</p>
              <p>{formatDate(selectedEscrow.createdAt)}</p>
            </div>
            
            <div>
              <p className="text-gray-600">Endereço do Destinatário:</p>
              <p className="font-mono text-sm break-all">{selectedEscrow.recipientAddress}</p>
            </div>
            
            <div>
              <p className="text-gray-600">Identidade Anônima:</p>
              <p className="font-mono text-sm">{selectedEscrow.creatorIdentityId}</p>
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-4">
            <h4 className="font-bold mb-2">Ações Disponíveis</h4>
            
            <div className="flex flex-wrap gap-2">
              {selectedEscrow.status === 'funded' && (
                <button
                  onClick={() => confirmDelivery(selectedEscrow.id)}
                  disabled={isLoading}
                  className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                >
                  Confirmar Entrega
                </button>
              )}
              
              {selectedEscrow.status === 'delivered' && (
                <button
                  onClick={() => releaseFunds(selectedEscrow.id)}
                  disabled={isLoading}
                  className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                >
                  Liberar Fundos
                </button>
              )}
              
              {(selectedEscrow.status === 'funded' || selectedEscrow.status === 'delivered') && (
                <button
                  onClick={() => {
                    const reason = prompt('Por favor, informe o motivo da disputa:');
                    if (reason) {
                      openDispute(selectedEscrow.id, reason);
                    }
                  }}
                  disabled={isLoading}
                  className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                >
                  Abrir Disputa
                </button>
              )}
              
              {(selectedEscrow.status === 'completed' || selectedEscrow.status === 'refunded') && (
                <span className="text-gray-500">Nenhuma ação disponível para este status</span>
              )}
              
              {selectedEscrow.status === 'disputed' && (
                <span className="text-gray-500">Disputa em andamento. Aguarde a resolução.</span>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Renderizar conteúdo com base na aba ativa
  const renderContent = () => {
    if (!identity) {
      return (
        <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-4">
          <p className="font-bold">Autenticação Necessária</p>
          <p>Você precisa estar autenticado com uma identidade anônima para acessar esta página.</p>
          <a 
            href="/auth" 
            className="inline-block mt-2 bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded"
          >
            Ir para Autenticação
          </a>
        </div>
      );
    }
    
    switch (activeTab) {
      case 'create':
        return renderCreateEscrowForm();
      case 'detail':
        return renderEscrowDetails();
      case 'list':
      default:
        return renderEscrowList();
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="bg-primary text-white p-6">
          <h1 className="text-2xl font-bold">Escrow com Autenticação Anônima</h1>
          <p className="mt-2">Gerencie seus escrows de forma anônima e segura</p>
        </div>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 m-4 rounded">
            {error}
          </div>
        )}
        
        <div className="p-6">
          {isLoading && (
            <div className="text-center py-4">
              <p className="text-gray-600">Carregando...</p>
            </div>
          )}
          
          {!isLoading && renderContent()}
        </div>
      </div>
    </div>
  );
};

export default EscrowWithAuthPage;
