import React from 'react';
import { Link } from 'react-router-dom';

const HomePage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="bg-primary text-white p-6">
          <h1 className="text-3xl font-bold">PayByt - Marketplace Descentralizado com Bitcoin</h1>
          <p className="mt-2 text-lg">Compre e venda com privacidade e segurança</p>
        </div>
        
        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-primary mb-4">Sistema de Autenticação Anônima</h2>
            <p className="mb-4">
              O PayByt implementa um sistema de autenticação anônima que permite aos usuários acessar o marketplace
              sem revelar suas informações pessoais, protegendo sua privacidade e segurança.
            </p>
            
            <div className="bg-gray-100 p-4 rounded-lg mb-4">
              <h3 className="font-bold text-lg mb-2">Principais características:</h3>
              <ul className="list-disc pl-5 space-y-2">
                <li>Identidades anônimas baseadas em criptografia de chave pública</li>
                <li>Zero-knowledge proofs para verificação sem revelação de dados</li>
                <li>Transações confidenciais que protegem remetente, destinatário e valor</li>
                <li>Autenticação baseada em desafio-resposta sem senhas</li>
                <li>Todas as chaves privadas permanecem apenas no navegador do cliente</li>
              </ul>
            </div>
            
            <div className="flex justify-center mt-6">
              <Link 
                to="/auth" 
                className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-6 rounded-lg transition duration-300"
              >
                Acessar com Autenticação Anônima
              </Link>
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-8">
            <h2 className="text-2xl font-bold text-primary mb-4">Sobre o PayByt</h2>
            <p className="mb-4">
              O PayByt é um marketplace descentralizado que utiliza exclusivamente Bitcoin como forma de pagamento.
              Nossa plataforma foi projetada para oferecer máxima privacidade e segurança para compradores e vendedores.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 mt-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-bold text-lg text-primary mb-2">Escrow Multisig</h3>
                <p>Sistema de escrow multisig 2-de-3 para garantir transações seguras entre compradores e vendedores.</p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-bold text-lg text-primary mb-2">Sem KYC</h3>
                <p>Opere sem necessidade de verificação de identidade, preservando sua privacidade.</p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-bold text-lg text-primary mb-2">Lightning Network</h3>
                <p>Suporte à Lightning Network para transações instantâneas e com taxas reduzidas.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
