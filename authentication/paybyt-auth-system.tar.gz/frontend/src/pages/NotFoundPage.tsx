import React from 'react';

const NotFoundPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-16 text-center">
      <h1 className="text-4xl font-bold text-primary mb-4">404</h1>
      <h2 className="text-2xl font-bold mb-6">Página não encontrada</h2>
      <p className="mb-8">A página que você está procurando não existe ou foi movida.</p>
      <a 
        href="/" 
        className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition duration-300"
      >
        Voltar para a página inicial
      </a>
    </div>
  );
};

export default NotFoundPage;
