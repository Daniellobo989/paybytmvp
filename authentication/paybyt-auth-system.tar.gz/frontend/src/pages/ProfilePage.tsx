import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProfilePage: React.FC = () => {
  const [identity, setIdentity] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [transactions, setTransactions] = useState<any[]>([]);

  useEffect(() => {
    // Carregar identidade do localStorage
    const storedIdentity = localStorage.getItem('anonymousIdentity');
    const storedToken = localStorage.getItem('anonymousToken');
    
    if (storedIdentity && storedToken) {
      setIdentity(JSON.parse(storedIdentity));
      
      // Configurar o token para requisições
      axios.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`;
      
      // Simular carregamento de transações
      // Em uma implementação real, isso viria da API
      setTransactions([
        {
          id: 'tx_' + Math.random().toString(36).substring(2, 10),
          type: 'compra',
          amount: 0.0025,
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'concluída'
        },
        {
          id: 'tx_' + Math.random().toString(36).substring(2, 10),
          type: 'venda',
          amount: 0.0058,
          date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'concluída'
        },
        {
          id: 'tx_' + Math.random().toString(36).substring(2, 10),
          type: 'compra',
          amount: 0.0012,
          date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'concluída'
        }
      ]);
    }
  }, []);

  // Verificar token
  const verifyToken = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await axios.get('/api/auth/verify-token');
      
      if (response.data.valid) {
        setIsLoading(false);
        return true;
      } else {
        setError('Token inválido ou expirado. Por favor, autentique-se novamente.');
        localStorage.removeItem('anonymousToken');
        setIsLoading(false);
        return false;
      }
    } catch (err: any) {
      setError('Erro ao verificar token: ' + (err.response?.data?.error || err.message));
      localStorage.removeItem('anonymousToken');
      setIsLoading(false);
      return false;
    }
  };

  // Gerar nova identidade
  const generateNewIdentity = async () => {
    if (window.confirm('Tem certeza que deseja gerar uma nova identidade? Você perderá acesso à identidade atual.')) {
      localStorage.removeItem('anonymousIdentity');
      localStorage.removeItem('anonymousToken');
      window.location.href = '/auth';
    }
  };

  // Formatar data
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!identity) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white shadow-lg rounded-lg p-6">
          <h1 className="text-2xl font-bold text-primary mb-4">Perfil Anônimo</h1>
          <p className="mb-4">Você não está autenticado. Por favor, autentique-se para acessar seu perfil.</p>
          <a 
            href="/auth" 
            className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          >
            Autenticar
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="bg-primary text-white p-6">
          <h1 className="text-2xl font-bold">Perfil Anônimo</h1>
          <p className="mt-2">Gerencie sua identidade anônima e visualize suas transações</p>
        </div>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 m-4 rounded">
            {error}
          </div>
        )}
        
        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-xl font-bold text-primary mb-4">Sua Identidade Anônima</h2>
            
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="mb-4">
                <p className="font-bold">ID da Identidade:</p>
                <p className="font-mono text-sm break-all">{identity.identityId}</p>
              </div>
              
              <div className="mb-4">
                <p className="font-bold">Chave Pública:</p>
                <p className="font-mono text-sm break-all">{identity.publicKey}</p>
              </div>
              
              <div className="mb-4">
                <p className="font-bold">Commitment:</p>
                <p className="font-mono text-sm break-all">{identity.commitment}</p>
              </div>
              
              <div className="bg-yellow-100 p-3 rounded-lg">
                <p className="text-yellow-800 text-sm">
                  <strong>Importante:</strong> Sua chave privada está armazenada apenas localmente no seu navegador.
                  Nunca compartilhe sua chave privada com ninguém.
                </p>
              </div>
            </div>
            
            <div className="mt-4">
              <button
                onClick={generateNewIdentity}
                className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
              >
                Gerar Nova Identidade
              </button>
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-6">
            <h2 className="text-xl font-bold text-primary mb-4">Histórico de Transações</h2>
            
            {transactions.length === 0 ? (
              <p className="text-gray-500">Nenhuma transação encontrada.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                  <thead>
                    <tr className="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
                      <th className="py-3 px-6 text-left">ID</th>
                      <th className="py-3 px-6 text-left">Tipo</th>
                      <th className="py-3 px-6 text-right">Valor (BTC)</th>
                      <th className="py-3 px-6 text-left">Data</th>
                      <th className="py-3 px-6 text-left">Status</th>
                    </tr>
                  </thead>
                  <tbody className="text-gray-600 text-sm">
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="py-3 px-6 text-left whitespace-nowrap">
                          <span className="font-mono">{tx.id}</span>
                        </td>
                        <td className="py-3 px-6 text-left">
                          <span className={`py-1 px-3 rounded-full text-xs ${
                            tx.type === 'compra' ? 'bg-green-200 text-green-800' : 'bg-blue-200 text-blue-800'
                          }`}>
                            {tx.type === 'compra' ? 'Compra' : 'Venda'}
                          </span>
                        </td>
                        <td className="py-3 px-6 text-right">
                          {tx.amount.toFixed(8)}
                        </td>
                        <td className="py-3 px-6 text-left">
                          {formatDate(tx.date)}
                        </td>
                        <td className="py-3 px-6 text-left">
                          <span className="py-1 px-3 rounded-full text-xs bg-green-200 text-green-800">
                            {tx.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
