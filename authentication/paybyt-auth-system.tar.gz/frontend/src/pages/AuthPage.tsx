import React, { useState, useEffect } from 'react';
import axios from 'axios';
import * as sodium from 'libsodium-wrappers';

const AuthenticationPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [identity, setIdentity] = useState(null);
  const [challenge, setChallenge] = useState(null);
  const [token, setToken] = useState(null);
  const [error, setError] = useState(null);
  const [step, setStep] = useState('initial'); // initial, identity, challenge, authenticated

  // Inicializar libsodium
  useEffect(() => {
    const initSodium = async () => {
      await sodium.ready;
      console.log('Libsodium inicializado');
    };
    initSodium();
  }, []);

  // Verificar se já existe uma identidade no localStorage
  useEffect(() => {
    const storedIdentity = localStorage.getItem('anonymousIdentity');
    const storedToken = localStorage.getItem('anonymousToken');
    
    if (storedIdentity) {
      setIdentity(JSON.parse(storedIdentity));
      setStep('identity');
      
      if (storedToken) {
        setToken(storedToken);
        setStep('authenticated');
      }
    }
  }, []);

  // Gerar uma nova identidade anônima
  const generateIdentity = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await axios.post('/api/auth/identity');
      const newIdentity = response.data;
      
      setIdentity(newIdentity);
      localStorage.setItem('anonymousIdentity', JSON.stringify(newIdentity));
      setStep('identity');
      
      console.log('Nova identidade gerada:', newIdentity);
    } catch (err) {
      setError('Erro ao gerar identidade: ' + (err.response?.data?.error || err.message));
      console.error('Erro ao gerar identidade:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Solicitar um desafio para autenticação
  const requestChallenge = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await axios.post('/api/auth/challenge', {
        identityId: identity.identityId
      });
      
      setChallenge(response.data);
      setStep('challenge');
      
      console.log('Desafio recebido:', response.data);
    } catch (err) {
      setError('Erro ao solicitar desafio: ' + (err.response?.data?.error || err.message));
      console.error('Erro ao solicitar desafio:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Assinar o desafio e verificar
  const signAndVerifyChallenge = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Converter a chave privada de hex para Uint8Array
      const privateKeyUint8 = sodium.from_hex(identity.privateKey);
      
      // Converter o desafio para Uint8Array
      const challengeUint8 = sodium.from_string(challenge.challenge);
      
      // Assinar o desafio
      const signatureUint8 = sodium.crypto_sign_detached(challengeUint8, privateKeyUint8);
      
      // Converter a assinatura para hex
      const signature = sodium.to_hex(signatureUint8);
      
      // Enviar a assinatura para verificação
      const response = await axios.post('/api/auth/verify', {
        identityId: identity.identityId,
        challenge: challenge.challenge,
        signature,
        publicKey: identity.publicKey
      });
      
      // Armazenar o token
      const newToken = response.data.token;
      setToken(newToken);
      localStorage.setItem('anonymousToken', newToken);
      setStep('authenticated');
      
      console.log('Autenticação bem-sucedida:', response.data);
      
      // Configurar o token para futuras requisições
      axios.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;
    } catch (err) {
      setError('Erro na autenticação: ' + (err.response?.data?.error || err.message));
      console.error('Erro na autenticação:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Logout - remover identidade e token
  const logout = () => {
    localStorage.removeItem('anonymousIdentity');
    localStorage.removeItem('anonymousToken');
    delete axios.defaults.headers.common['Authorization'];
    setIdentity(null);
    setChallenge(null);
    setToken(null);
    setStep('initial');
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-2xl p-6 mt-10">
      <h1 className="text-2xl font-bold text-primary mb-6">Autenticação Anônima</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {step === 'initial' && (
        <div>
          <p className="mb-4">
            Bem-vindo ao sistema de autenticação anônima do PayByt. Este sistema permite que você
            acesse o marketplace sem revelar sua identidade real.
          </p>
          <button
            onClick={generateIdentity}
            disabled={isLoading}
            className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          >
            {isLoading ? 'Gerando...' : 'Gerar Identidade Anônima'}
          </button>
        </div>
      )}
      
      {step === 'identity' && (
        <div>
          <p className="mb-4">
            Sua identidade anônima foi gerada com sucesso. Você pode usar esta identidade para
            autenticar-se no marketplace PayByt sem revelar suas informações pessoais.
          </p>
          
          <div className="bg-gray-100 p-4 rounded mb-4">
            <p className="font-bold">ID da Identidade:</p>
            <p className="font-mono text-sm break-all mb-2">{identity.identityId}</p>
            
            <p className="font-bold">Chave Pública:</p>
            <p className="font-mono text-sm break-all mb-2">{identity.publicKey}</p>
            
            <div className="bg-yellow-100 p-2 rounded mb-2">
              <p className="text-yellow-800 text-sm">
                <strong>Importante:</strong> Sua chave privada está armazenada localmente e nunca é enviada ao servidor.
                Se você limpar os dados do navegador, perderá acesso a esta identidade.
              </p>
            </div>
          </div>
          
          <div className="flex space-x-4">
            <button
              onClick={requestChallenge}
              disabled={isLoading}
              className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              {isLoading ? 'Processando...' : 'Autenticar'}
            </button>
            
            <button
              onClick={logout}
              className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Remover Identidade
            </button>
          </div>
        </div>
      )}
      
      {step === 'challenge' && (
        <div>
          <p className="mb-4">
            Um desafio foi gerado para verificar sua identidade. Ao clicar em "Verificar", seu navegador
            assinará o desafio com sua chave privada sem revelá-la ao servidor.
          </p>
          
          <div className="bg-gray-100 p-4 rounded mb-4">
            <p className="font-bold">Desafio:</p>
            <p className="font-mono text-sm break-all">{challenge.challenge}</p>
          </div>
          
          <div className="flex space-x-4">
            <button
              onClick={signAndVerifyChallenge}
              disabled={isLoading}
              className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              {isLoading ? 'Verificando...' : 'Verificar'}
            </button>
            
            <button
              onClick={() => setStep('identity')}
              className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Voltar
            </button>
          </div>
        </div>
      )}
      
      {step === 'authenticated' && (
        <div>
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <p className="font-bold">Autenticado com Sucesso!</p>
            <p>Você está autenticado anonimamente no marketplace PayByt.</p>
          </div>
          
          <div className="bg-gray-100 p-4 rounded mb-4">
            <p className="font-bold">Identidade Anônima:</p>
            <p className="font-mono text-sm break-all mb-2">{identity.identityId}</p>
            
            <p className="font-bold">Status:</p>
            <p className="text-green-600 font-bold">Verificado</p>
          </div>
          
          <div className="flex space-x-4">
            <button
              onClick={() => window.location.href = '/'}
              className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Ir para o Marketplace
            </button>
            
            <button
              onClick={logout}
              className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Sair
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AuthenticationPage;
