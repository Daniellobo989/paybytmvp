import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white py-6 mt-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <div className="flex items-center justify-center md:justify-start">
              <span className="text-bitcoin text-xl mr-2">₿</span>
              <span className="font-bold text-xl">PayByt</span>
            </div>
            <p className="text-gray-400 text-sm mt-1">Marketplace descentralizado com Bitcoin</p>
          </div>
          
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-8">
            <div>
              <h3 className="font-bold mb-2 text-center md:text-left">Recursos</h3>
              <ul className="space-y-1 text-gray-400 text-sm text-center md:text-left">
                <li><a href="#" className="hover:text-white">Escrow Multisig</a></li>
                <li><a href="#" className="hover:text-white">Autenticação Anônima</a></li>
                <li><a href="#" className="hover:text-white">Lightning Network</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-2 text-center md:text-left">Suporte</h3>
              <ul className="space-y-1 text-gray-400 text-sm text-center md:text-left">
                <li><a href="#" className="hover:text-white">FAQ</a></li>
                <li><a href="#" className="hover:text-white">Documentação</a></li>
                <li><a href="#" className="hover:text-white">Contato</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-2 text-center md:text-left">Legal</h3>
              <ul className="space-y-1 text-gray-400 text-sm text-center md:text-left">
                <li><a href="#" className="hover:text-white">Termos de Uso</a></li>
                <li><a href="#" className="hover:text-white">Política de Privacidade</a></li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-6 pt-6 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} PayByt. Todos os direitos reservados.</p>
          <p className="mt-1">Construído com tecnologias de privacidade e segurança de ponta.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
