import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header: React.FC = () => {
  const location = useLocation();
  const isAuthenticated = localStorage.getItem('anonymousToken') !== null;
  const identity = localStorage.getItem('anonymousIdentity') 
    ? JSON.parse(localStorage.getItem('anonymousIdentity') || '{}')
    : null;

  return (
    <header className="bg-primary shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="text-white font-bold text-xl flex items-center">
              <span className="text-bitcoin mr-1">₿</span>
              <span>PayByt</span>
            </Link>
          </div>
          
          <nav className="flex items-center space-x-6">
            <Link 
              to="/" 
              className={`text-white hover:text-gray-200 ${location.pathname === '/' ? 'font-bold' : ''}`}
            >
              Início
            </Link>
            
            <Link 
              to="/auth" 
              className={`text-white hover:text-gray-200 ${location.pathname === '/auth' ? 'font-bold' : ''}`}
            >
              Autenticação
            </Link>
            
            <Link 
              to="/profile" 
              className={`text-white hover:text-gray-200 ${location.pathname === '/profile' ? 'font-bold' : ''}`}
            >
              Perfil
            </Link>
            
            {isAuthenticated ? (
              <div className="bg-white bg-opacity-10 rounded-full px-4 py-1 text-white text-sm">
                <span className="mr-2">ID:</span>
                <span className="font-mono">{identity?.identityId.substring(0, 8)}...</span>
              </div>
            ) : (
              <Link 
                to="/auth" 
                className="bg-bitcoin hover:bg-bitcoin-dark text-white font-bold py-2 px-4 rounded"
              >
                Entrar
              </Link>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
